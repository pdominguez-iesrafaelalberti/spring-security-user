package com.dwes.security;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.dwes.security.entities.Book;
import com.dwes.security.entities.User;
import com.dwes.security.repos.BookRepository;
import com.dwes.security.repos.UserRepository;

@Component
public class DatabaseLoader implements ApplicationRunner{
	
	@Autowired
	BookRepository repository;
	@Autowired
	UserRepository userrepository;

	@Override
	public void run(ApplicationArguments args) throws Exception {

	        	BCryptPasswordEncoder bCryptPasswordEncode = new BCryptPasswordEncoder();
	            repository.save(new Book("A Guide to the Bodhisattva Way of Life", "Santideva", new BigDecimal("15.41")));
	            repository.save(new Book("The Life-Changing Magic of Tidying Up", "Marie Kondo", new BigDecimal("9.69")));
	            repository.save(new Book("Refactoring: Improving the Design of Existing Code", "Martin Fowler", new BigDecimal("47.99")));
	            userrepository.save(new User("usuario", bCryptPasswordEncode.encode("usuario"), "user"));
	            userrepository.save(new User("admin2",  bCryptPasswordEncode.encode("admin2"), "admin"));
	            userrepository.save(new User("test10",  "test10", "admin"));
	    
	    }
		
	}


    

