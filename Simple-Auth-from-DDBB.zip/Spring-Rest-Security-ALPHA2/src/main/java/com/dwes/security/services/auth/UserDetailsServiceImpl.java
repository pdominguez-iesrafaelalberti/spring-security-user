package com.dwes.security.services.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.dwes.security.entities.User;
import com.dwes.security.repos.UserRepository;


@Service
public class UserDetailsServiceImpl implements UserDetailsService{
    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String username) {
    	UserDetails userdatails = null;
        User user = userRepository.findByUsername(username);

        userdatails = org.springframework.security.core.userdetails.User.builder()
			     .username(user.getUsername())
			     .password((user.getPassword()))
			     .roles(user.getRol())
			     .build();
       
       
        return userdatails;

    }
    
 

}
