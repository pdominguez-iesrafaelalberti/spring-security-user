package com.dwes.security.error;

public class ExistUserFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ExistUserFoundException(String message) {
        super("User error : " + message);
       
    }

}
