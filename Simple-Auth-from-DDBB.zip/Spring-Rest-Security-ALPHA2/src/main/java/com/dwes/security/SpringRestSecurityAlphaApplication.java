package com.dwes.security;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;




//https://www.websparrow.org/spring/spring-boot-spring-security-with-jpa-authentication-and-mysql

@SpringBootApplication
public class SpringRestSecurityAlphaApplication {
	

	public static void main(String[] args) {
		SpringApplication.run(SpringRestSecurityAlphaApplication.class, args);
	}
	   
    
}

